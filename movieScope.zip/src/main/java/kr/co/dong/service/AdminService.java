package kr.co.dong.service;

import kr.co.dong.DTO.AdminDTO;

public interface AdminService {

	public void insert (AdminDTO ad);
	public void delete (int u_no);
}

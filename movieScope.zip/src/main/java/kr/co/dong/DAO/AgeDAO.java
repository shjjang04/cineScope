package kr.co.dong.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

public interface AgeDAO {
	public int search(int m_number);
	public List<Integer> searchMovie(int m_age);
}

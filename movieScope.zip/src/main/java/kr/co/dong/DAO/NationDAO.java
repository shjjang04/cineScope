package kr.co.dong.DAO;

import java.util.List;

import org.springframework.stereotype.Repository;

public interface NationDAO {
	public String search(int m_number);
	public List<Integer> searchMovie(String m_nation);
}
